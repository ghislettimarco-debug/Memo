# Memo Corsi - App Android (build dal telefono, senza PC)

Le notifiche sono LOCALI (AlarmManager di Android): funzionano OFFLINE,
con app chiusa e schermo spento. Al riavvio del telefono gli allarmi
vengono ripianificati automaticamente.

## Come ottenere l'APK (tutto dal telefono, gratis)

1. Crea un account su https://github.com (dal browser del telefono)
2. Crea un NUOVO repository privato (pulsante "New", nome: memo-corsi)
3. Carica in una sola volta TUTTI i file e le cartelle di questo progetto:
   - package.json
   - capacitor.config.json
   - www/ (con index.html)
   - .github/workflows/build-apk.yml
   Tramite "uploading an existing file": premi "Add file" > "Upload files".
   IMPORTANTE: mantieni le sottocartelle (www/ e .github/workflows/).
   Consiglio: comprimi tutto in uno ZIP sul telefono e carica lo ZIP:
   GitHub accetta upload di file grandi e gestisce lo zip.
   (Su Android: app File > seleziona i file > Comprimi. Su iPhone: Files > comprimi.)

4. Vai su github.com/TUO-UTENTE/memo-corsi
5. Tocca il tasto verde "Actions" (in alto)
6. A sinistra scegli "Build APK", poi premi "Run workflow"
7. Dopo 5-15 min (cerchietto giallo -> spunta verde) tocca "Build APK"
   e scarica l'artifact "MemoCorsi-APK" (è uno zip contenente app-debug.apk)
8. Apri lo zip, tocca app-debug.apk e installa
   (concedi "Installa app da fonti sconosciute" quando richiesto)

## Uso
- All'avvio concedi il permesso notifiche (toccando la campanella)
- Ogni corso pianificato genera allarmi nativi per ogni azione del modello

## Note tecniche
- npm install copia automaticamente il bridge Capacitor autentico
  (node_modules/@capacitor/core/dist/capacitor.js) dentro www/,
  quindi l'app NON ha bisogno di internet per funzionare
- Se GitHub chiede di abilitare Actions al primo accesso: conferma
- L'APK debug e' per uso personale; per pubblicarla sul Play Store
  servirebbe un keystore (possibile in un secondo momento)
